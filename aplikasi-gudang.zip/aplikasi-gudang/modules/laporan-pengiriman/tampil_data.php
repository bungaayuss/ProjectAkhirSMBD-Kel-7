<?php
// Mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di-include oleh file lain
// Jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    // Alihkan ke halaman error 404
    header('location: 404.html');
}
// Jika file di-include oleh file lain, tampilkan isi file
else {
    // Ambil data dari VIEW "laporan_pengiriman"
    $query = mysqli_query($mysqli, "SELECT * FROM laporan_pengiriman") or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
?>

    <div class="panel-header bg-secondary-gradient">
        <div class="page-inner py-4">
            <div class="page-header text-white">
                <!-- Judul halaman -->
                <h4 class="page-title text-white"><i class="fas fa-file mr-2"></i> Laporan Pengiriman</h4>
                <!-- Breadcrumbs -->
                <ul class="breadcrumbs">
                    <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Laporan</a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Pengiriman</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="page-inner mt--5">
    <div class="card">
        <div class="card-header">
            <!-- Judul tabel -->
            <div class="card-title">
            <i class="fas fa-file"></i> Laporan Pengiriman
        </div>
            <div class="card-body">
                <div class="table-responsive">
                    <!-- Tabel untuk menampilkan data dari VIEW "laporan_pengiriman" -->
                    <table id="basic-datatables" class="display table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">No.</th>
                                <th class="text-center">ID Pengiriman</th>
                                <th class="text-center">Tanggal Pengiriman</th>
                                <th class="text-center">Tipe Proses</th>
                                <th class="text-center">Gudang Pengirim</th>
                                <th class="text-center">Gudang Tujuan</th>
                                <th class="text-center">Nama Barang</th>
                                <th class="text-center">Keterangan Pengiriman</th>
                                <th class="text-center">Status Pengiriman</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Variabel untuk nomor urut tabel
                            $no = 1;
                            // Ambil data hasil query
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <!-- Tampilkan data -->
                                <tr>
                                    <td class="text-center"><?php echo $no++; ?></td>
                                    <td class="text-center"><?php echo $data['id_pengiriman']; ?></td>
                                    <td class="text-center"><?php echo $data['tanggal_pengiriman']; ?></td>
                                    <td class="text-center"><?php echo $data['tipe_proses']; ?></td>
                                    <td class="text-center"><?php echo $data['gudang_pengirim']; ?></td>
                                    <td class="text-center"><?php echo $data['gudang']; ?></td>
                                    <td class="text-center"><?php echo $data['nama_barang']; ?></td>
                                    <td class="text-center"><?php echo $data['keterangan_pengiriman']; ?></td>
                                    <td class="text-center"><?php echo $data['status_pengiriman']; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php
}
?>
