<?php
session_start(); // Mengaktifkan session

// Pengecekan session login user 
// Jika user belum login
if (empty($_SESSION['username']) && empty($_SESSION['password'])) {
    // Alihkan ke halaman login dan tampilkan pesan peringatan login
    header('location: ../../login.php?pesan=2');
} else {
    // Panggil file "database.php" untuk koneksi ke database
    require_once "../../config/database.php";
    // Panggil file "fungsi_tanggal_indo.php" untuk membuat format tanggal Indonesia
    require_once "../../helper/fungsi_tanggal_indo.php";

    // Ambil data GET dari tombol export
    $tanggal_awal  = $_GET['tanggal_awal'];
    $tanggal_akhir = $_GET['tanggal_akhir'];

    // Fungsi header untuk mengirimkan raw data Excel
    header("Content-type: application/vnd-ms-excel");
    // Mendefinisikan nama file hasil ekspor "Laporan Data Barang Masuk.xls"
    header("Content-Disposition: attachment; filename=Laporan Data Barang Masuk.xls");
?>
    <!-- Halaman HTML yang akan diexport ke Excel -->
    <!-- Judul tabel -->
    <center>
        <h4>
            LAPORAN DATA BARANG MASUK DAN KELUAR<br>
            Tanggal <?php echo $tanggal_awal; ?> s.d <?php echo $tanggal_akhir; ?>
        </h4>
    </center>
    <!-- Tabel untuk menampilkan data dari database -->
    <table border="1">
        <thead>
            <tr style="background-color:#6861ce;color:#fff">
                <th height="30" align="center" vertical="center">No.</th>
                <th height="30" align="center" vertical="center">Jenis Transaksi</th>
                <th height="30" align="center" vertical="center">ID Transaksi</th>
                <th height="30" align="center" vertical="center">Tanggal</th>
                <th height="30" align="center" vertical="center">Barang</th>
                <th height="30" align="center" vertical="center">Harga per Unit</th>
                <th height="30" align="center" vertical="center">Jumlah</th>
                <th height="30" align="center" vertical="center">Total Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Ubah format tanggal menjadi Tahun-Bulan-Hari (Y-m-d)
            $tanggal_awal  = date('Y-m-d', strtotime($tanggal_awal));
            $tanggal_akhir = date('Y-m-d', strtotime($tanggal_akhir));

            // Variabel untuk nomor urut tabel 
            $no = 1;

            // SQL statement untuk menampilkan data dari tabel "laporanmasukkeluar" berdasarkan "tanggal"
            $query = mysqli_query($mysqli, "SELECT * FROM laporanmasukkeluar WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir' ORDER BY id_transaksi ASC")
                or die('Ada kesalahan pada query tampil data: ' . mysqli_error($mysqli));
            
            $total_masuk = 0;
            $total_keluar = 0;

            // Ambil data hasil query
            while ($data = mysqli_fetch_assoc($query)) { ?>
                <!-- Tampilkan data -->
                <tr>
                    <td width="50" align="center"><?php echo $no++; ?></td>
                    <td width="90" align="center"><?php echo $data['jenis_transaksi']; ?></td>
                    <td width="90" align="center"><?php echo $data['id_transaksi']; ?></td>
                    <td width="70" align="center"><?php echo date('d-m-Y', strtotime($data['tanggal'])); ?></td>
                    <td width="150"><?php echo $data['barang']; ?></td>
                    <td width="130" align="right">Rp. <?php echo number_format($data['harga_per_unit'], 0, '', '.'); ?></td>
                    <td width="130" align="right"><?php echo number_format($data['jumlah'], 0, '', '.'); ?></td>
                    <td width="130" align="right">Rp. <?php echo number_format($data['total_harga'], 0, '', '.'); ?></td>
                </tr>
                <?php
                if ($data['jenis_transaksi'] === 'Masuk') {
                    $total_masuk += $data['total_harga'];
                } elseif ($data['jenis_transaksi'] === 'Keluar') {
                    $total_keluar += $data['total_harga'];
                }
            } ?>
            <tr>
                <td colspan="7" align="center" class="font-weight-bold">Total Barang Masuk</td>
                <td align="right" class="font-weight-bold">Rp. <?php echo number_format($total_masuk, 0, '', '.'); ?></td>
            </tr>
            <tr>
                <td colspan="7" align="center" class="font-weight-bold">Total Barang Keluar</td>
                <td align="right" class="font-weight-bold">Rp. <?php echo number_format($total_keluar, 0, '', '.'); ?></td>
            </tr>
        </tbody>
    </table>
    <br>
    <div style="text-align:right">............, <?php echo tanggal_indo(date('Y-m-d')); ?></div>
<?php } ?>
