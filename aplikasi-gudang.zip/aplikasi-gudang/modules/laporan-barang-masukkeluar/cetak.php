<?php
require('fpdf.php');
require('config.php'); // Adjust the path to your database configuration file

class PDF extends FPDF
{
    // Page header
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Laporan Barang Masuk dan Keluar', 0, 1, 'C');
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(10, 10, 'No', 1);
        $this->Cell(40, 10, 'Jenis Transaksi', 1);
        $this->Cell(30, 10, 'ID Transaksi', 1);
        $this->Cell(30, 10, 'Tanggal', 1);
        $this->Cell(30, 10, 'Barang', 1);
        $this->Cell(30, 10, 'Harga per Unit', 1);
        $this->Cell(20, 10, 'Jumlah', 1);
        $this->Cell(30, 10, 'Total Harga', 1);
        $this->Ln();
    }

    // Page footer
    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

// Create instance of PDF class
$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);

// Fetch data from the database
$query = mysqli_query($mysqli, "SELECT * FROM laporanmasukkeluar ORDER BY id_transaksi ASC")
    or die('Ada kesalahan pada query tampil data: ' . mysqli_error($mysqli));

$no = 1;
$total_masuk = 0;
$total_keluar = 0;

while ($data = mysqli_fetch_assoc($query)) {
    $pdf->Cell(10, 10, $no++, 1);
    $pdf->Cell(40, 10, $data['jenis_transaksi'], 1);
    $pdf->Cell(30, 10, $data['id_transaksi'], 1);
    $pdf->Cell(30, 10, date('d-m-Y', strtotime($data['tanggal'])), 1);
    $pdf->Cell(30, 10, $data['barang'], 1);
    $pdf->Cell(30, 10, 'Rp. ' . number_format($data['harga_per_unit'], 0, '', '.'), 1, 0, 'R');
    $pdf->Cell(20, 10, number_format($data['jumlah'], 0, '', '.'), 1, 0, 'R');
    $pdf->Cell(30, 10, 'Rp. ' . number_format($data['total_harga'], 0, '', '.'), 1, 0, 'R');
    $pdf->Ln();

    if ($data['jenis_transaksi'] === 'Masuk') {
        $total_masuk += $data['total_harga'];
    } elseif ($data['jenis_transaksi'] === 'Keluar') {
        $total_keluar += $data['total_harga'];
    }
}

// Display totals
$pdf->Cell(190, 10, 'Total Barang Masuk: Rp. ' . number_format($total_masuk, 0, '', '.'), 1, 0, 'R');
$pdf->Ln();
$pdf->Cell(190, 10, 'Total Barang Keluar: Rp. ' . number_format($total_keluar, 0, '', '.'), 1, 0, 'R');

// Output the PDF
$pdf->Output();
