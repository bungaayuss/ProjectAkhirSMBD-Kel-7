<?php
// Mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di-include oleh file lain
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    header('location: 404.html');
} else {

    // Fungsi untuk mendapatkan nama bulan dari angka bulan
    function getNamaBulan($bulan)
    {
        $nama_bulan = array(
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni',
            7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        );
        return $nama_bulan[$bulan];
    }
?>
    <div class="panel-header bg-secondary-gradient">
        <div class="page-inner py-4">
            <div class="page-header text-white">
                <!-- judul halaman -->
                <h4 class="page-title text-white"><i class="fas fa-file-export mr-2"></i> Laporan Barang Terlaris</h4>
                <!-- breadcrumbs -->
                <ul class="breadcrumbs">
                    <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Laporan</a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Barang Terlaris</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="page-inner mt--5">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Laporan Data Barang Terlaris</div>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label for="bulan_awal">Pilih Bulan Awal</label>
                                <select name="bulan_awal" id="bulan_awal" class="form-control">
                                    <?php for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo getNamaBulan($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label for="bulan_akhir">Pilih Bulan Akhir</label>
                                <select name="bulan_akhir" id="bulan_akhir" class="form-control">
                                    <?php for ($i = 1; $i <= 12; $i++) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo getNamaBulan($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="form-group">
                                <label for="tahun">Pilih Tahun</label>
                                <select name="tahun" id="tahun" class="form-control">
                                    <?php for ($i = date('Y'); $i >= 2010; $i--) : ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <label for="submit" class="invisible">Submit</label>
                            <input type="submit" name="submit" id="submit" class="btn btn-secondary btn-round btn-block mt-4" value="Tampilkan">
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php
        // Jika tombol submit ditekan
        if (isset($_POST['submit'])) {
            $bulan_awal = $_POST['bulan_awal'];
            $bulan_akhir = $_POST['bulan_akhir'];
            $tahun = $_POST['tahun'];
        ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <i class="fas fa-file-alt mr-2"></i> Laporan Data Barang Terlaris <?php echo getNamaBulan($bulan_awal) . ' ' ."sampai ", getNamaBulan($bulan_akhir) . ' ' . $tahun; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="display table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">ID Barang</th>
                                    <th class="text-center">Nama Barang</th>
                                    <th class="text-center">Total Terjual</th>
                                    <th class="text-center">Harga per Barang</th>
                                    <th class="text-center">Total Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;

                                // Panggil prosedur
                                $query = mysqli_query($mysqli, "CALL GetBarangTerlarisRange($bulan_awal, $bulan_akhir, $tahun)") or die('Ada kesalahan pada query tampil data: ' . mysqli_error($mysqli));
                                while ($data = mysqli_fetch_assoc($query)) { ?>
                                    <tr>
                                        <td width="50" class="text-center"><?php echo $no++; ?></td>
                                        <td width="90" class="text-center"><?php echo $data['id_barang']; ?></td>
                                        <td width="350"><?php echo $data['nama_barang']; ?></td>
                                        <td width="70" class="text-right"><?php echo number_format($data['total_terjual'], 0, '', '.'); ?></td>
                                        <td width="70" class="text-right">Rp. <?php echo number_format($data['harga_per_barang'], 0, '', '.'); ?></td>
                                        <td width="70" class="text-right">Rp. <?php echo number_format($data['total_harga'], 0, '', '.'); ?></td>
                                    </tr>
                                <?php
                                }
                                // Kembali ke koneksi normal
                                mysqli_next_result($mysqli);
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
<?php
}
?>