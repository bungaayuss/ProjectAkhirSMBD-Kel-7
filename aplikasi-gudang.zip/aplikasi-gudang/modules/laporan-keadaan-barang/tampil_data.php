<?php
// Mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di-include oleh file lain
// Jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
  // Alihkan ke halaman error 404
  header('location: 404.html');
}
// Jika file di-include oleh file lain, tampilkan isi file
else {
?>

  <div class="panel-header bg-secondary-gradient">
    <div class="page-inner py-4">
      <div class="page-header text-white">
        <!-- Judul halaman -->
        <h4 class="page-title text-white"><i class="fas fa-file-alt mr-2"></i> Laporan Keadaan Barang</h4>
        <!-- Breadcrumbs -->
        <ul class="breadcrumbs">
          <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
          <li class="separator"><i class="flaticon-right-arrow"></i></li>
          <li class="nav-item"><a>Laporan</a></li>
          <li class="separator"><i class="flaticon-right-arrow"></i></li>
          <li class="nav-item"><a>Keadaan Barang</a></li>
        </ul>
      </div>
    </div>
  </div>

  <div class="page-inner mt--5">
    <div class="card">
      <div class="card-header">
        <!-- Judul tabel -->
        <div class="card-title">
          <i class="fas fa-file-alt mr-2"></i> Laporan Data Keadaan Barang
        </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <!-- Tabel untuk menampilkan data dari database -->
          <table id="basic-datatables" class="display table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th class="text-center">No.</th>
                <th class="text-center">ID Keadaan Barang</th>
                <th class="text-center">Nama Barang</th>
                <th class="text-center">Tanggal Cek</th>
                <th class="text-center">Stok</th>
                <th class="text-center">Kondisi Barang</th>
                <th class="text-center">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              <?php
              // Variabel untuk nomor urut tabel
              $no = 1;

              // SQL statement untuk menampilkan data dari VIEW "laporan_keadaan"
              $query = mysqli_query($mysqli, "SELECT * FROM laporan_keadaan") or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
              // Ambil data hasil query
              while ($data = mysqli_fetch_assoc($query)) { ?>
                <!-- Tampilkan data -->
                <tr>
                  <td width="50" class="text-center"><?php echo $no++; ?></td>
                  <td width="60" class="text-center"><?php echo $data['id_keadaan']; ?></td>
                  <td width="70" class="text-center"><?php echo $data['nama_barang']; ?></td>
                  <td width="70" class="text-center"><?php echo date('d-m-Y', strtotime($data['tanggal_cek'])); ?></td>
                  <td width="60" class="text-center"><?php echo $data['stok']; ?></td>
                  <td width="70" class="text-center"><?php echo $data['kondisi_barang']; ?></td>
                  <td width="70"><?php echo $data['keterangan']; ?></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

<?php
}
?>
