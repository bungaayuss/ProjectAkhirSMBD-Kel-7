<?php
// Mencegah direct access file PHP agar file PHP tidak bisa diakses secara langsung dari browser dan hanya dapat dijalankan ketika di-include oleh file lain
// Jika file diakses secara langsung
if (basename($_SERVER['PHP_SELF']) === basename(__FILE__)) {
    // Alihkan ke halaman error 404
    header('location: 404.html');
}
// Jika file di-include oleh file lain, tampilkan isi file
else {
?>

    <div class="panel-header bg-secondary-gradient">
        <div class="page-inner py-4">
            <div class="page-header text-white">
                <!-- Judul halaman -->
                <h4 class="page-title text-white"><i class="fas fa-file-signature mr-2"></i> Laporan Stok</h4>
                <!-- Breadcrumbs -->
                <ul class="breadcrumbs">
                    <li class="nav-home"><a href="?module=dashboard"><i class="flaticon-home text-white"></i></a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Laporan</a></li>
                    <li class="separator"><i class="flaticon-right-arrow"></i></li>
                    <li class="nav-item"><a>Stok</a></li>
                </ul>
            </div>
        </div>
    </div>

    <?php
    // Ambil data stok dari VIEW "stok"
    $query = mysqli_query($mysqli, "SELECT * FROM stok ORDER BY id_barang ASC") or die('Ada kesalahan pada query tampil data : ' . mysqli_error($mysqli));
    ?>

    <div class="page-inner mt--5">
        <div class="card">
            <div class="card-header">
                <!-- Judul form -->
                <div class="card-title">
                <i class="fas fa-file-signature"></i>Laporan Stok</div>
            </div>
            <!-- Tabel untuk menampilkan data dari VIEW "stok" -->
            <div class="card-body">
                <div class="table-responsive">
                    <table id="basic-datatables" class="display table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th class="text-center">No.</th>
                                <th class="text-center">ID Barang</th>
                                <th class="text-center">Nama Barang</th>
                                <th class="text-center">Stok</th>
                                <th class="text-center">Satuan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Variabel untuk nomor urut tabel
                            $no = 1;
                            // Ambil data hasil query
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <!-- Tampilkan data -->
                                <tr>
                                    <td width="50" class="text-center"><?php echo $no++; ?></td>
                                    <td width="80" class="text-center"><?php echo $data['id_barang']; ?></td>
                                    <td width="350"><?php echo $data['nama_barang']; ?></td>
                                    <td width="70" class="text-right"><?php echo $data['current_stock']; ?></td>
                                    <td width="70"><?php echo $data['nama_satuan']; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php
}
?>
