/*
SQLyog Community v13.2.0 (64 bit)
MySQL - 10.4.14-MariaDB : Database - gudang
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gudang` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `gudang`;

/*Table structure for table `tbl_barang` */

DROP TABLE IF EXISTS `tbl_barang`;

CREATE TABLE `tbl_barang` (
  `id_barang` int(11) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(100) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `harga_jual` decimal(15,2) NOT NULL,
  `stok_minimum` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `satuan` int(11) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `satuan` (`satuan`),
  CONSTRAINT `tbl_barang_ibfk_1` FOREIGN KEY (`satuan`) REFERENCES `tbl_satuan` (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_barang` */

insert  into `tbl_barang`(`id_barang`,`nama_barang`,`harga`,`harga_jual`,`stok_minimum`,`stok`,`satuan`,`foto`) values 
(1,'Buku',10.00,15.00,20,100,1,'buku.jpg'),
(2,'Gula',50000.00,60000.00,50,200,2,'gula.jpg'),
(3,'Minyak Goreng',20000.00,25000.00,30,150,3,'minyak.jpg');

/*Table structure for table `tbl_barang_keluar` */

DROP TABLE IF EXISTS `tbl_barang_keluar`;

CREATE TABLE `tbl_barang_keluar` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `barang` int(11) NOT NULL,
  `penerima` varchar(100) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `barang` (`barang`),
  CONSTRAINT `tbl_barang_keluar_ibfk_1` FOREIGN KEY (`barang`) REFERENCES `tbl_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_barang_keluar` */

insert  into `tbl_barang_keluar`(`id_transaksi`,`tanggal`,`barang`,`penerima`,`harga`,`jumlah`,`total_harga`) values 
(1,'2024-06-03',1,'Toko X',15.00,30,450.00),
(2,'2024-06-04',2,'Toko Y',60000.00,80,4800000.00),
(3,'2024-06-05',3,'Toko Z',25000.00,50,1250000.00);

/*Table structure for table `tbl_barang_masuk` */

DROP TABLE IF EXISTS `tbl_barang_masuk`;

CREATE TABLE `tbl_barang_masuk` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `barang` int(11) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `harga` decimal(15,2) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `barang` (`barang`),
  CONSTRAINT `tbl_barang_masuk_ibfk_1` FOREIGN KEY (`barang`) REFERENCES `tbl_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_barang_masuk` */

insert  into `tbl_barang_masuk`(`id_transaksi`,`tanggal`,`barang`,`supplier`,`harga`,`jumlah`,`total_harga`) values 
(1,'2024-06-01',1,'Supplier A',9.00,50,450.00),
(2,'2024-06-02',2,'Supplier B',48000.00,100,4800000.00),
(3,'2024-06-03',3,'Supplier C',19500.00,80,1560000.00);

/*Table structure for table `tbl_keadaan_barang` */

DROP TABLE IF EXISTS `tbl_keadaan_barang`;

CREATE TABLE `tbl_keadaan_barang` (
  `id_keadaan` int(11) NOT NULL AUTO_INCREMENT,
  `barang` int(11) NOT NULL,
  `tanggal_cek` date NOT NULL,
  `stok` int(11) NOT NULL,
  `kondisi_barang` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  PRIMARY KEY (`id_keadaan`),
  KEY `barang` (`barang`),
  CONSTRAINT `tbl_keadaan_barang_ibfk_1` FOREIGN KEY (`barang`) REFERENCES `tbl_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_keadaan_barang` */

insert  into `tbl_keadaan_barang`(`id_keadaan`,`barang`,`tanggal_cek`,`stok`,`kondisi_barang`,`keterangan`) values 
(1,1,'2024-06-01',95,'Baik','Barang dalam kondisi baik'),
(2,2,'2024-06-01',300,'Baik','Barang dalam kondisi baik'),
(3,3,'2024-06-01',130,'Baik','Barang dalam kondisi baik');

/*Table structure for table `tbl_pengiriman` */

DROP TABLE IF EXISTS `tbl_pengiriman`;

CREATE TABLE `tbl_pengiriman` (
  `id_pengiriman` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `tipe_proses` varchar(50) NOT NULL,
  `gudang_pengirim` varchar(100) NOT NULL,
  `gudang` varchar(100) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `STATUS` varchar(50) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id_pengiriman`),
  KEY `id_barang` (`id_barang`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_pengiriman_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `tbl_barang` (`id_barang`),
  CONSTRAINT `tbl_pengiriman_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_pengiriman` */

insert  into `tbl_pengiriman`(`id_pengiriman`,`tanggal`,`tipe_proses`,`gudang_pengirim`,`gudang`,`keterangan`,`STATUS`,`id_barang`,`id_user`) values 
(1,'2024-06-05','Pengiriman','Gudang A','Gudang B','Pengiriman kebutuhan bulan depan','Sedang dikirim',1,1),
(2,'2024-06-06','Transfer','Gudang B','Gudang C','Pindah gudang untuk penjualan di cabang baru','Dalam proses',2,2),
(3,'2024-06-07','Pengiriman','Gudang C','Gudang A','Restok barang habis','Dikirim',3,3);

/*Table structure for table `tbl_penyesuaian` */

DROP TABLE IF EXISTS `tbl_penyesuaian`;

CREATE TABLE `tbl_penyesuaian` (
  `id_penyesuaian` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `barang` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `keterangan` text DEFAULT NULL,
  PRIMARY KEY (`id_penyesuaian`),
  KEY `barang` (`barang`),
  CONSTRAINT `tbl_penyesuaian_ibfk_1` FOREIGN KEY (`barang`) REFERENCES `tbl_barang` (`id_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_penyesuaian` */

insert  into `tbl_penyesuaian`(`id_penyesuaian`,`tanggal`,`barang`,`jumlah`,`keterangan`) values 
(1,'2024-06-01',1,-5,'Retur barang rusak'),
(2,'2024-06-04',2,20,'Penambahan stok untuk kebutuhan promosi'),
(3,'2024-06-07',3,-10,'Pemusnahan barang kadaluarsa');

/*Table structure for table `tbl_satuan` */

DROP TABLE IF EXISTS `tbl_satuan`;

CREATE TABLE `tbl_satuan` (
  `id_satuan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_satuan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_satuan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_satuan` */

insert  into `tbl_satuan`(`id_satuan`,`nama_satuan`) values 
(1,'Pcs'),
(2,'Kg'),
(3,'Liter');

/*Table structure for table `tbl_user` */

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `hak_akses` enum('Administrator','Admin Gudang','Kepala Gudang') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

/*Data for the table `tbl_user` */

insert  into `tbl_user`(`id_user`,`nama_user`,`username`,`PASSWORD`,`hak_akses`) values 
(1,'Admin 1','admin1','password1','Administrator'),
(2,'Admin 2','admin2','password2','Admin Gudang'),
(3,'Admin 3','admin3','password3','Kepala Gudang');

/* Trigger structure for table `tbl_barang_keluar` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `stok_keluar` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `stok_keluar` AFTER INSERT ON `tbl_barang_keluar` FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok - NEW.jumlah WHERE id_barang = NEW.barang;
END */$$


DELIMITER ;

/* Trigger structure for table `tbl_barang_keluar` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `hapus_stok_keluar` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `hapus_stok_keluar` BEFORE DELETE ON `tbl_barang_keluar` FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok + OLD.jumlah WHERE id_barang = OLD.barang;
END */$$


DELIMITER ;

/* Trigger structure for table `tbl_barang_masuk` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `stok_masuk` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `stok_masuk` AFTER INSERT ON `tbl_barang_masuk` FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok + NEW.jumlah WHERE id_barang = NEW.barang;
END */$$


DELIMITER ;

/* Trigger structure for table `tbl_barang_masuk` */

DELIMITER $$

/*!50003 DROP TRIGGER*//*!50032 IF EXISTS */ /*!50003 `hapus_stok_masuk` */$$

/*!50003 CREATE */ /*!50017 DEFINER = 'root'@'localhost' */ /*!50003 TRIGGER `hapus_stok_masuk` BEFORE DELETE ON `tbl_barang_masuk` FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok - OLD.jumlah WHERE id_barang = OLD.barang;
END */$$


DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
