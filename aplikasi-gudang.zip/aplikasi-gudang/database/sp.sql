-- 1 --
DELIMITER //
CREATE PROCEDURE InsertBarangMasuk(
    IN p_id_transaksi VARCHAR(255),
    IN p_tanggal DATE,
    IN p_barang INT,
    IN p_supplier VARCHAR,
    IN p_harga DECIMAL(10,2),
    IN p_jumlah INT,
    IN p_total_harga DECIMAL(15,2)
)
BEGIN
    INSERT INTO tbl_barang_masuk(id_transaksi, tanggal, barang, supplier, harga, jumlah, total_harga) 
    VALUES(p_id_transaksi, p_tanggal, p_barang, p_supplier, p_harga, p_jumlah, p_total_harga);
END //
DELIMITER ;


-- 2 --
DELIMITER //
CREATE PROCEDURE insert_keadaan_barang(
    IN p_id_keadaan INT,
    IN p_barang VARCHAR(255),
    IN p_tanggal_cek DATE,
    IN p_stok INT,
    IN p_kondisi_barang VARCHAR(255),
    IN p_keterangan TEXT
)
BEGIN
    INSERT INTO tbl_keadaan_barang (id_keadaan, barang, tanggal_cek, stok, kondisi_barang, keterangan)
    VALUES (p_id_keadaan, p_barang, p_tanggal_cek, p_stok, p_kondisi_barang, p_keterangan);
END //
DELIMITER ;

-- 3 --
DELIMITER //
CREATE PROCEDURE delete_keadaan_barang(
    IN p_id_keadaan INT
)
BEGIN
    DELETE FROM tbl_keadaan_barang WHERE id_keadaan = p_id_keadaan;
END //
DELIMITER ;

-- 4 --
DELIMITER //
CREATE PROCEDURE insert_penyesuaian(
    IN p_id_penyesuaian INT,
    IN p_tanggal DATE,
    IN p_barang VARCHAR(255),
    IN p_jumlah INT,
    IN p_keterangan TEXT
)
BEGIN
    INSERT INTO tbl_penyesuaian (id_penyesuaian, tanggal, barang, jumlah, keterangan)
    VALUES (p_id_penyesuaian, p_tanggal, p_barang, p_jumlah, p_keterangan);
END //
DELIMITER ;


-- 5 --
DELIMITER //
CREATE PROCEDURE delete_penyesuaian(
    IN p_id_penyesuaian INT
)
BEGIN
    DELETE FROM tbl_penyesuaian WHERE id_penyesuaian = p_id_penyesuaian;
END //
DELIMITER ;


-- 6 --
DELIMITER //
CREATE PROCEDURE GetBarangTerlarisRange(
    IN bulan_awal INT, 
    IN bulan_akhir INT, 
    IN tahun INT
)
BEGIN
    DECLARE current_bulan INT DEFAULT bulan_awal;

    CREATE TEMPORARY TABLE IF NOT EXISTS temp_terlaris (
        id_barang INT,
        nama_barang VARCHAR(255),
        total_terjual INT,
        harga_per_barang DECIMAL(10,2),
        total_harga DECIMAL(15,2)
    );

    WHILE current_bulan <= bulan_akhir DO
        INSERT INTO temp_terlaris (id_barang, nama_barang, total_terjual, harga_per_barang, total_harga)
        SELECT 
            bk.barang AS id_barang, 
            b.nama_barang, 
            SUM(bk.jumlah) AS total_terjual,
            b.harga AS harga_per_barang,
            SUM(bk.jumlah * b.harga) AS total_harga
        FROM 
            tbl_barang_keluar bk
        JOIN 
            tbl_barang b ON bk.barang = b.id_barang
        WHERE 
            MONTH(bk.tanggal) = current_bulan AND YEAR(bk.tanggal) = tahun
        GROUP BY 
            bk.barang, b.nama_barang, b.harga
        ORDER BY 
            total_terjual DESC;

        SET current_bulan = current_bulan + 1;
    END WHILE;

    SELECT * FROM temp_terlaris;

    DROP TEMPORARY TABLE IF EXISTS temp_terlaris;
END //
DELIMITER ;


drop PROCEDURE GetBarangTerlarisRange;