
-- 1
DELIMITER //
CREATE TRIGGER hapus_stok_keluar BEFORE DELETE ON tbl_barang_keluar
FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok + OLD.jumlah WHERE id_barang = OLD.barang;
END//
DELIMITER ;


-- 2
DELIMITER //
CREATE TRIGGER hapus_stok_masuk BEFORE DELETE ON tbl_barang_masuk
FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok - OLD.jumlah WHERE id_barang = OLD.barang;
END//
DELIMITER ;


-- 3
DELIMITER //
CREATE TRIGGER stok_keluar AFTER INSERT ON tbl_barang_keluar
FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok - NEW.jumlah WHERE id_barang = NEW.barang;
END//
DELIMITER ;



-- 4
DELIMITER //
CREATE TRIGGER stok_masuk AFTER INSERT ON tbl_barang_masuk
FOR EACH ROW BEGIN
    UPDATE tbl_barang SET stok = stok + NEW.jumlah WHERE id_barang = NEW.barang;
END//
DELIMITER ;



-- 5
DELIMITER //
CREATE TRIGGER update_stok BEFORE UPDATE ON tbl_keadaan_barang
FOR EACH ROW
BEGIN
	IF new.stok < 0 THEN
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Stok Tidak Boleh Kurang Dari Nol";
	END IF;
END //
DELIMITER;