--view---
CREATE VIEW laporanmasukkeluar AS
SELECT 
    'Masuk' AS jenis_transaksi,
    bm.id_transaksi AS id_transaksi,
    bm.tanggal AS tanggal,
    b.nama_barang AS barang,
    bm.harga AS harga_per_unit,
    bm.jumlah AS jumlah,
    bm.total_harga AS total_harga
FROM tbl_barang_masuk bm
JOIN tbl_barang b ON bm.barang = b.id_barang
UNION ALL
SELECT 
    'Keluar' AS jenis_transaksi,
    bk.id_transaksi AS id_transaksi,
    bk.tanggal AS tanggal,
    b.nama_barang AS barang,
    bk.harga AS harga_per_unit,
    bk.jumlah AS jumlah,
    bk.total_harga AS total_harga
FROM tbl_barang_keluar bk
JOIN tbl_barang b ON bk.barang = b.id_barang;

SELECT * FROM laporanmasukkeluar;

DROP VIEW laporanmasukkeluar;

--2---
CREATE VIEW stok AS
SELECT 
    b.id_barang,
    b.nama_barang,
    b.stok AS current_stock,
    s.nama_satuan
FROM tbl_barang b
JOIN tbl_satuan s ON b.satuan = s.id_satuan;

SELECT * FROM stok;

--3--
CREATE VIEW `laporan_pengiriman` AS
SELECT
    pk.`id_pengiriman`,
    pk.`tanggal` AS `tanggal_pengiriman`,
    pk.`tipe_proses`,
    pk.`gudang_pengirim`,
    pk.`gudang`,
    b.`nama_barang`,
    pk.`keterangan` AS `keterangan_pengiriman`,
    pk.`STATUS` AS `status_pengiriman`
FROM
    `tbl_pengiriman` pk
INNER JOIN
    `tbl_barang` b ON pk.`id_barang` = b.`id_barang`;

SELECT * FROM laporan_pengiriman;

DROP VIEW laporan_pengiriman;

--4--
CREATE VIEW `laporan_penyesuaian` AS
SELECT 
    p.`id_penyesuaian` AS `id_penyesuaian`,
    p.`tanggal` AS `tanggal`,
    b.`nama_barang` AS `nama_barang`,
    p.`jumlah` AS `jumlah`,
    p.`keterangan` AS `keterangan`,
    s.`nama_user` AS `nama_user`
FROM
    `tbl_penyesuaian` p
        JOIN
    `tbl_barang` b ON p.`barang` = b.`id_barang`
        JOIN
    `tbl_pengiriman` u ON b.`id_barang` = u.`id_barang`
	JOIN
	`tbl_user` s ON u.`id_user` = s.`id_user`
ORDER BY p.`tanggal` DESC
LIMIT 10;

SELECT * FROM laporan_penyesuaian;

DROP VIEW laporan_penyesuaian;

-- 5--
CREATE VIEW `laporan_keadaan` AS
SELECT 
    kb.`id_keadaan` AS `id_keadaan`,
    kb.`tanggal_cek` AS `tanggal_cek`,
    b.`nama_barang` AS `nama_barang`,
    kb.`stok` AS `stok`,
    kb.`kondisi_barang` AS `kondisi_barang`,
    kb.`keterangan` AS `keterangan`
FROM
    `tbl_keadaan_barang` kb
        JOIN
    `tbl_barang` b ON kb.`barang` = b.`id_barang`
ORDER BY kb.`tanggal_cek` DESC
LIMIT 10;

SELECT * FROM laporan_keadaan;
